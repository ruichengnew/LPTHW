#version 2
#解决了数字的问题，因为是“是”的关系，所以比较好处理
#并没有很好的解决”error”的问题，因为是"不是"的问题，不太好准确找到判断语句
#按照nosetest来看，这个代码比那个代码快了0.01秒左右，可能是因为在nested——loop中少了两个type，并且多了两个if-statement
direction = ['north', 'south', 'east']
verb = ['kill', 'go', 'eat']
stop = ['the', 'in', 'of']
noun = ['princess', 'bear']

type = ['direction', 'verb', 'stop', 'noun']

def scan(words):
    word_list = []
    for var in words.split():
        for ty in type:
                if var in eval(ty):
                    word_list.append((ty, var))

        if var.isdigit():
            word_list.append(('number', int(var)))

        if var.isupper():
            word_list.append(('error', var))

    return word_list

#问题，无法很好的处理error，我是看准所有的error都是大写字母处理的，比较简单
