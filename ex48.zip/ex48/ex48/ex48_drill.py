#Question 1
#感觉class，就是把def的其中一个变量变成self，然后形成一个，可以轻易更改的变量
#其实到目前为止，我仍然没有很明显的感觉到class的优势在哪里，反倒是，def好用，方便，快捷
class ParserError(Exception):
    pass

class Sentence(object):

    def __init__(self, subject, verb, obj):
        self.subject = subject[1]
        self.verb = verb[1]
        self.object = obj[1]

class Word_list(object):

    def __init__(self, word_list):
        self.word_list = word_list

    def peek(self):
        if self.word_list:
            word = self.word_list[0]
            return word[0]
        else:
            return None

    def match(self, expecting):
        if self.word_list:
            word = self.word_list.pop(0)

            if word[0] == expecting:
                return word
            else:
                return None
        else:
            return None

    def skip(self, word_type):
        while peek(self) == word_type:
            match(self, word_type)

    def parse_subject(self):
        skip(self, 'stop')
        next_word = peek(self)

        if next_word == 'noun':
            return match(self, 'noun')
        elif next_word == 'verb':
            return ('noun', 'player')
        else:
            raise ParserError("Expected a verb next.")

    def parse_verb(self):
        skip(self, 'stop')

        if peek(self) == 'verb':
            return match(self, 'verb')
        else:
            raise ParserError("Expected a verb next.")

    def parse_object(self):
        skip(self, 'stop')
        next_word = peek(self)

        if next_word == 'noun':
            return match(self, 'noun')
        elif next_word == 'direction':
            return match(self, 'direction')
        else:
            raise ParserError("Expected a noun or direction next.")

    def parse_sentence(self):
        subj = parse_subject(self)
        verb = parse_verb(self)
        obj = parse_object(self)

        return Sentence(subj, verb, obj)
