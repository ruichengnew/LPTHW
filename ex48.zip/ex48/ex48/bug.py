class Word_list(object):

    def __init__(self, word_list):
        self.word_list = word_list

    def peek(self):
        if self.word_list:
            word = self.word_list[0]
            print(word[0])
        else:
            return None

l = Word_list([('verb', 'go')])
l.peek()
