from nose.tools import *
from ex48 import parser

def test_peek():
    assert_equal(parser.peek([('noun', 'bear')]), 'noun')

def test_match():
    assert_equal(parser.match([('noun', 'bear')], 'noun'), ('noun', 'bear'))
    assert_equal(parser.match([('noun', 'bear')], 'direction'), None)

word_list = [('verb', 'go'), ('stop', 'the'), ('stop', 'at'), ('direction', 'north')]
def test_parse_subject():
    assert_equal(parser.parse_subject(word_list), ('noun', 'player'))

def test_parse_verb():
    assert_equal(parser.parse_verb(word_list), ('verb', 'go'))

def test_parse_object():
    assert_equal(parser.parse_object(word_list), ('direction', 'north'))


def test_parse_sentence():
    word_list = [('verb', 'go'), ('stop', 'the'), ('stop', 'at'), ('direction', 'north')]
    x = parser.parse_sentence(word_list)
    assert_equal(x.subject, 'player')
    assert_equal(x.object,  'north')
    assert_equal(x.verb, 'go')
