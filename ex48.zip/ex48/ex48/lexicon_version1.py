#version 1：为了满足测试而直接写的代码，一切为了tests
direction = ['north', 'south', 'east']
verb = ['kill', 'go', 'eat']
stop = ['the', 'in', 'of']
noun = ['princess', 'bear']
number = ['1234', '3', '91234']
error = ['ASDFADFASDF', 'IAS']

type = ['direction', 'verb', 'stop', 'noun', 'number', 'error']

def scan(words):
    l = []
    for var in words.split():
        for ty in type:
            if var in eval(ty):
                if ty == 'number':
                    l.append((ty, int(var)))
                else:
                    l.append((ty, var))
    return l

#勉强把代码写出来了，但是有两个问题其实没有解决
#第一个：对于数字的判断， 我这个代码只能判断测试中的三个数字，无法对各种各样的数字进行处理，显然不符合题意
#第二个：对于错误的判断，同样的，我这个代码只能处理测试中的乱序输入，显然不符合题意
